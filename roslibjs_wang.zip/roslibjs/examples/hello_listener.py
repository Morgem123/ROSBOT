#!/usr/bin/env python

import rospy
from std_msgs.msg import String
import pygame

def callback(data):
    rospy.loginfo("I heard: %s", data.data)
    
    pygame.mixer.init()
    
    if data.data == "table1-1":
        pygame.mixer.music.load("table1-1.wav")
    elif data.data == "table1-2":
        pygame.mixer.music.load("table1-2.wav")
    elif data.data == "table2-1":
        pygame.mixer.music.load("table2-1.wav")
    elif data.data == "table2-2":
        pygame.mixer.music.load("table2-2.wav")
    elif data.data == "table3-1":
        pygame.mixer.music.load("table3-1.wav")
    elif data.data == "table3-2":
        pygame.mixer.music.load("table3-2.wav")
    elif data.data == "table1in":
        pygame.mixer.music.load("table1-in.wav")
    elif data.data == "table1out":
        pygame.mixer.music.load("table1-out.wav")
    elif data.data == "table2in":
        pygame.mixer.music.load("table2-in.wav")
    elif data.data == "table2out":
        pygame.mixer.music.load("table2-out.wav")
    elif data.data == "table3in":
        pygame.mixer.music.load("table3-in.wav")
    elif data.data == "table3out":
        pygame.mixer.music.load("table3-out.wav")
    else:
        rospy.logwarn("Received unknown message: %s", data.data)
        return
    
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        rospy.sleep(0.1)

def listener():
    rospy.init_node('table_listener', anonymous=True)
    rospy.Subscriber("/table_topic", String, callback)
    rospy.spin()

if __name__ == '__main__':
    listener()




